---
name: Tidak Hadir
about: Doakan kami di acara pernikahan kami
title: Namamu
labels: tidak hadir
assignees: ''

---

#### Doa
*Baarakallahu laka wa baaraka ‘alaika wa jama’a bainakuma fii khair*
Semoga Allah memberkahimu ketika bahagia dan ketika susah, serta mengumpulkan kalian berdua dalam kebaikan

#### Ucapan Selamat dan Harapan
Selamat ...
Semoga ...
